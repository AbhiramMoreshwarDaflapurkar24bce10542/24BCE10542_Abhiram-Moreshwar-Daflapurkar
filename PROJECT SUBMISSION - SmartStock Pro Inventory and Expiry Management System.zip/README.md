# SmartStock Pro

## Inventory and Expiry Management System

A distributed inventory and expiry management solution built with **Spring Boot** and **MongoDB**.

---

### Project Overview
SmartStock Pro helps organizations manage product inventory, suppliers, sales, stock monitoring, expiry tracking, reminders, analytics, replication, and sharding. It demonstrates:

- MongoDB CRUD operations
- Document relationships
- Aggregation pipelines
- Replica sets & sharded clusters
- Console‑based execution & REST API (Postman)

---

### Objectives
- Efficient product inventory management  
- Low‑stock & expiry alerts  
- Sales reporting & analytics  
- Supplier & category management  
- Showcase MongoDB advanced features (replication, sharding)

---

### Technology Stack
| Technology               | Version |
|--------------------------|---------|
| Java                     | 21 |
| Spring Boot              | 3.5.x |
| Spring Data MongoDB      | 4.x |
| MongoDB Community Server | 8.x |
| Maven                    | 3.9+ |
| Antigravity IDE          | Latest |
| VS Code                  | Latest |
| Postman                  | Latest |
| Git                      | Latest |

---

### Project Architecture
```
Client (Postman / Console)
   ↓
Controllers
   ↓
Services
   ↓
Repositories
   ↓
MongoDB Database
```

### Source Layout
```
src/main/java/com/SmartStockPro/app
├─ controller
│   ├─ CategoryController
│   ├─ ProductController
│   ├─ SupplierController
│   ├─ SaleController
│   ├─ ReminderController
│   └─ AnalyticsController
├─ service
│   ├─ CategoryService
│   ├─ ProductService
│   ├─ SupplierService
│   ├─ SaleService
│   ├─ ReminderService
│   ├─ SchedulerService
│   └─ AnalyticsService
├─ repository
├─ model
├─ config
│   └─ DatabaseSeeder
└─ AppApplication.java
```

---

### Features
- **Category**: CRUD  
- **Product**: CRUD, search, availability check  
- **Supplier**: CRUD  
- **Sales**: Record, view, monthly reports  
- **Reminders**: Low‑stock & expiry alerts, scheduled notifications  
- **Analytics**: Inventory, sales, top‑selling, low‑stock, expiring products

---

### How to Run
1. **Start MongoDB**
   ```cmd
   net start MongoDB
   mongosh   # should show `test>`
   ```

2. **Open Project** in Antigravity IDE (primary) or VS Code (secondary).

3. **Configure DB** – edit `src/main/resources/application.properties`:
   ```properties
   spring.data.mongodb.uri=mongodb://localhost:27017/smartstock_pro
   server.port=8080
   spring.application.name=SmartStockPro
   ```

4. **Install Dependencies**
   ```cmd
   mvn clean install
   ```

5. **Run Application**
   - **Antigravity IDE**: Click the **Run** button (or open `AppApplication.java` → Run)
   - **Maven**: `mvn spring-boot:run`
- **Open Main Class**: `AppApplication.java` (line 11) – the entry point of the Spring Boot application.

6. **Verify Startup** – you should see:
   ```
   SmartStock Pro: Distributed Inventory and Expiry Management System
   Started AppApplication
   Tomcat started on port(s): 8080
   Database seeding completed successfully

   **Data Seeding**: The application seeds initial data using the `DatabaseSeeder` class located at `src/main/java/com/SmartStockPro/app/config/DatabaseSeeder.java`.
   ```

7. **Use the CLI** (optional) – run the compiled JAR or `java -jar` and follow the console menu. *Note*: The console expects user input; ensure a terminal is attached.

---

### REST API Endpoints
#### Categories
| Method | Endpoint |
|--------|----------|
| POST   | `/api/categories` |
| GET    | `/api/categories` |
| GET    | `/api/categories/{id}` |
| PUT    | `/api/categories/{id}` |
| DELETE | `/api/categories/{id}` |

#### Products
| Method | Endpoint |
|--------|----------|
| POST   | `/api/products` |
| GET    | `/api/products` |
| GET    | `/api/products/{id}` |
| PUT    | `/api/products/{id}` |
| DELETE | `/api/products/{id}` |
| GET    | `/api/products/search/{name}` |
| GET    | `/api/products/availability/{name}` |

#### Suppliers
| Method | Endpoint |
|--------|----------|
| POST   | `/api/suppliers` |
| GET    | `/api/suppliers` |
| GET    | `/api/suppliers/{id}` |
| PUT    | `/api/suppliers/{id}` |
| DELETE | `/api/suppliers/{id}` |

#### Sales
| Method | Endpoint |
|--------|----------|
| POST   | `/api/sales` |
| GET    | `/api/sales` |
| GET    | `/api/sales/report` |

#### Reminders
| Method | Endpoint |
|--------|----------|
| POST   | `/api/reminders` |
| GET    | `/api/reminders` |

#### Analytics
| Method | Endpoint |
|--------|----------|
| GET    | `/api/analytics/category-inventory` |
| GET    | `/api/analytics/monthly-sales` |
| GET    | `/api/analytics/top-selling` |
| GET    | `/api/analytics/low-stock` |
| GET    | `/api/analytics/expiring` |

---

### MongoDB Relationships
- **One‑to‑One**: Product ↔ InventoryDetails
- **One‑to‑Many**: Category → Products
### MongoDB Relationships
MongoDB does not enforce PK and FK constraints, but references are maintained manually.

**One-to-One Relationship**
Product ↔ InventoryDetails

**Product**
```json
{
  "_id": "P101",
  "name": "Amul Gold Milk"
}
```

**InventoryDetails**
```json
{
  "_id": "I101",
  "productId": "P101",
  "warehouseLocation": "Cold Storage"
}
```

**One-to-Many Relationship**
Category → Products

**Category**
```json
{
  "_id": "C101",
  "name": "Dairy"
}
```

**Products**
```json
[
  { "_id": "P201", "categoryId": "C101", "name": "Milk" },
  { "_id": "P202", "categoryId": "C101", "name": "Cheese" }
]
```

**Many-to-One Relationship**
Supplier → Products

**Supplier**
```json
{
  "_id": "S101",
  "name": "Supplier A"
}
```

**Products** (excerpt)
```json
{
  "_id": "P301",
  "supplierId": "S101"
}
```

**One-to-Many (Product → Sales)**

**Product**
```json
{
  "_id": "P401",
  "name": "Butter"
}
```

**Sales**
```json
[
  { "_id": "SALE1", "productId": "P401" },
  { "_id": "SALE2", "productId": "P401" }
]
```

One Product can have many Sales Records.
- **One‑to‑Many**: Product → Sales

---

### Automation (SchedulerService)
- Low‑stock & expiry monitoring
- Daily at 08:00 AM (`@Scheduled(cron = "0 0 8 * * ?")`)
- Demo: every 60 s (`@Scheduled(fixedRate = 60000)`)

---

### Testing Tools
- Postman (API testing)
- MongoDB Compass (DB visualization)
- Antigravity IDE / VS Code (debugging)

---



### Screenshots
Included screenshots in folder OUTPUT SCREENSHOTS FOLDER for startup, API responses, Compass collections, aggregation reports, replication & sharding setup, CLI menu, etc.

---




